<<<<<<< HEAD
package com.ssafy.vue.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan(
		basePackages = "com.ssafy.vue.mapper"
)
=======
package com.ssafy.vue.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan(
		basePackages = "com.ssafy.vue.mapper"
)
>>>>>>> 8dc7dd045e0223a381a2fd61cc44650e6dfb224f
public class DatabaseConfig {}